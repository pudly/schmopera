		</div><!-- main -->
	</div><!-- wrapper -->

	<?php wp_footer(); ?>
</body>
</html>